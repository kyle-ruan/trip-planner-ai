# Trip Planner

A TypeScript application that uses LangChain and OpenAI to plan trips by finding flights, checking weather, and booking hotels.

## Features

- Multi-city trip planning
- Flight search with price comparison
- Weather forecasting for travel dates
- Hotel recommendations based on ratings and amenities
- Activity suggestions based on weather conditions
- Budget breakdown and analysis
- Detailed logging with color-coded console output and file logging

## Setup

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file in the root directory and add your OpenAI API key:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

## Usage

### Development

Run the application in development mode:

```
npm run dev
```

### Production

Build the application:

```
npm run build
```

Run the built application:

```
npm start
```

## Project Structure

The project follows a modular architecture for better organization and maintainability:

```
src/
├── api/                  # Mock API functions for different services
│   ├── activityApi.ts    # Activity search API
│   ├── budgetApi.ts      # Budget calculation API
│   ├── flightApi.ts      # Flight search API
│   ├── hotelApi.ts       # Hotel search API
│   └── weatherApi.ts     # Weather forecast API
├── tools/                # LangChain tools for the agent
│   ├── activityTool.ts   # Tool for finding activities
│   ├── budgetTool.ts     # Tool for calculating budgets
│   ├── flightTool.ts     # Tool for finding flights
│   ├── hotelTool.ts      # Tool for finding hotels
│   └── weatherTool.ts    # Tool for checking weather
├── types/                # TypeScript type definitions
│   └── index.ts          # Common types used across the application
├── utils/                # Utility functions
│   ├── logger.ts         # Logging utilities
│   └── mockData.ts       # Mock data for simulating API responses
└── index.ts              # Main application entry point
```

## Logs

Detailed logs are saved to the `logs/trip-planner.log` file, which includes all API calls, tool usage, and agent thinking process.

## Customization

You can customize the trip planning by modifying the parameters in the `runAdvancedTripPlanner` function call in `src/index.ts`:

```typescript
runAdvancedTripPlanner(
  ["Tokyo", "Kyoto", "Osaka"], // Destinations
  "2025-04-10", // Start date
  "2025-04-20", // End date
  "New York", // Departure city
  3000, // Budget in USD
  2 // Number of travelers
)
```
